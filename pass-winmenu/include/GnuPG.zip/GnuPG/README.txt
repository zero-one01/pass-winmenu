
                          GNUPG for Windows
                         ===================

This is GnuPG for Windows, version 2.1.21.

Content:

     1. Important notes
     2. Changes
     3. GnuPG README file
     4. Legal notices


1. Important Notes
==================

This is the core part of the GnuPG system as used by several other
frontend programs.  This installer does not provide any graphical
frontend and thus almost everything needs to be done on the command
line.  However, a small native Windows GUI tool is included which is
used by GnuPG to ask for passphrases.  It provides only the basic
functionality and is installed under the name "pinentry-basic.exe".
Other software using this core component may install a different
version of such a tool under the name "pinentry.exe" or configure the
gpg-agent to use that version.

See https://gnupg.org for latest news.  HowTo documents and manuals
can be found there but some have also been installed on your machine.

Development and maintenance of GnuPG is mostly financed by donations;
please see https://gnupg.org/donate/ for details.


2. Record of Changes
====================

This is a list of changes to the GnuPG core for this and the previous
release.

Noteworthy changes in version 2.1.21 (2017-05-15)
-------------------------------------------------

  * gpg,gpgsm: Fix corruption of old style keyring.gpg files.  This
    bug was introduced with version 2.1.20.  Note that the default
    pubring.kbx format was not affected.

  * gpg,dirmngr: Removed the skeleton config file support.  The
    system's standard methods for providing default configuration
    files should be used instead.

  * w32: The Windows installer now allows installion of GnuPG without
    Administrator permissions.

  * gpg: Fixed import filter property match bug.

  * scd: Removed Linux support for Cardman 4040 PCMCIA reader.

  * scd: Fixed some corner case bugs in resume/suspend handling.

  * Many minor bug fixes and code cleanup.


Noteworthy changes in version 2.1.20 (2017-04-03)
-------------------------------------------------

  * gpg: New properties 'expired', 'revoked', and 'disabled' for the
    import and export filters.

  * gpg: New command --quick-set-primary-uid.

  * gpg: New compliance field for the --with-colon key listing.

  * gpg: Changed the key parser to generalize the processing of local
    meta data packets.

  * gpg: Fixed assertion failure in the TOFU trust model.

  * gpg: Fixed exporting of zero length user ID packets.

  * scd: Improved support for multiple readers.

  * scd: Fixed timeout handling for key generation.

  * agent: New option --enable-extended-key-format.

  * dirmngr: Do not add a keyserver to a new dirmngr.conf.  Dirmngr
    uses a default keyserver.

  * dimngr: Do not treat TLS warning alerts as severe error when
    building with GNUTLS.

  * dirmngr: Actually take /etc/hosts in account.

  * wks: Fixed client problems on Windows.  Published keys are now set
    to world-readable.

  * tests: Fixed creation of temporary directories.

  * A socket directory for a non standard GNUGHOME is now created on
    the fly under /run/user.  Thus "gpgconf --create-socketdir" is now
    optional.  The use of "gpgconf --remove-socketdir" to clean up
    obsolete socket directories is however recommended to avoid
    cluttering /run/user with useless directories.

  * Fixed build problems on some platforms.





3. GnuPG README file
====================

Below is the README file as distributed with the GnuPG source.

                       The GNU Privacy Guard 2
                      =========================
                             Version 2.1

          Copyright 1997-2017 Werner Koch
          Copyright 1998-2017 Free Software Foundation, Inc.


* INTRODUCTION

  GnuPG is a complete and free implementation of the OpenPGP standard
  as defined by RFC4880 (also known as PGP).  GnuPG enables encryption
  and signing of data and communication, and features a versatile key
  management system as well as access modules for public key
  directories.

  GnuPG, also known as GPG, is a command line tool with features for
  easy integration with other applications.  A wealth of frontend
  applications and libraries are available that make use of GnuPG.
  Starting with version 2 GnuPG provides support for S/MIME and Secure
  Shell in addition to OpenPGP.

  GnuPG is Free Software (meaning that it respects your freedom). It
  can be freely used, modified and distributed under the terms of the
  GNU General Public License.

  Note that the 2.0 series of GnuPG will reach end-of-life on
  2017-12-31.  It is not possible to install a 2.1.x version along
  with any 2.0.x version.  However, it is possible to install GnuPG
  1.4 along with a 2.x version.


* BUILD INSTRUCTIONS

  GnuPG 2.1 depends on the following GnuPG related packages:

    npth         (ftp://ftp.gnupg.org/gcrypt/npth/)
    libgpg-error (ftp://ftp.gnupg.org/gcrypt/libgpg-error/)
    libgcrypt    (ftp://ftp.gnupg.org/gcrypt/libgcrypt/)
    libksba      (ftp://ftp.gnupg.org/gcrypt/libksba/)
    libassuan    (ftp://ftp.gnupg.org/gcrypt/libassuan/)

  You should get the latest versions of course, the GnuPG configure
  script complains if a version is not sufficient.

  For some advanced features several other libraries are required.
  The configure script prints diagnostic messages if one of these
  libraries is not available and a feature will not be available..

  You also need the Pinentry package for most functions of GnuPG;
  however it is not a build requirement.  Pinentry is available at
  ftp://ftp.gnupg.org/gcrypt/pinentry/ .

  After building and installing the above packages in the order as
  given above, you may continue with GnuPG installation (you may also
  just try to build GnuPG to see whether your already installed
  versions are sufficient).

  As with all packages, you just have to do

    ./configure
    make
    make install

  (Before doing install you might need to become root.)

  If everything succeeds, you have a working GnuPG with support for
  OpenPGP, S/MIME, ssh-agent, and smartcards.  Note that there is no
  binary gpg but a gpg2 so that this package won't conflict with a
  GnuPG 1.4 installation.  gpg2 behaves just like gpg.

  In case of problem please ask on the gnupg-users@gnupg.org mailing
  list for advise.

  Instruction on how to build for Windows can be found in the file
  doc/HACKING in the section "How to build an installer for Windows".
  This requires some experience as developer.

  Note that the PKITS tests are always skipped unless you copy the
  PKITS test data file into the tests/pkits directory.  There is no
  need to run these test and some of them may even fail because the
  test scripts are not yet complete.

  You may run

    gpgconf --list-dirs

  to view the default directories used by GnuPG.

  To quickly build all required software without installing it, the
  Speedo method may be used:

    make -f build-aux/speedo.mk  native

  This method downloads all required libraries and does a native build
  of GnuPG to PLAY/inst/.  GNU make is required and you need to set
  LD_LIBRARY_PATH to $(pwd)/PLAY/inst/lib to test the binaries.

** Specific build problems on some machines:

*** Apple OSX 10.x using XCode

  On some versions the correct location of a header file can't be
  detected by configure.  To fix that you should run configure like
  this

    ./configure  gl_cv_absolute_stdint_h=/usr/include/stdint.h

  Add other options as needed.


*** Systems without a full C99 compiler

  If you run into problems with your compiler complaining about dns.c
  you may use

    ./configure --disable-libdns

  Add other options as needed.


* MIGRATION from 1.4 or 2.0 to 2.1

  The major change in 2.1 is gpg-agent taking care of the OpenPGP
  secret keys (those managed by GPG).  The former file "secring.gpg"
  will not be used anymore.  Newly generated keys are stored in the
  agent's key store directory "~/.gnupg/private-keys-v1.d/".  The
  first time gpg needs a secret key it checks whether a "secring.gpg"
  exists and copies them to the new store.  The old secring.gpg is
  kept for use by older versions of gpg.

  Note that gpg-agent now uses a fixed socket.  All tools will start
  the gpg-agent as needed.  The formerly used environment variable
  GPG_AGENT_INFO is ignored by 2.1.  The SSH_AUTH_SOCK environment
  variable should be set to a fixed value.

  The Dirmngr is now part of GnuPG proper and also used to access
  OpenPGP keyservers.  The directory layout of Dirmngr changed to make
  use of the GnuPG directories.  Dirmngr is started by gpg or gpgsm as
  needed. There is no more need to install a separate Dirmngr package.

* RECOMMENDATIONS

** Socket directory

  GnuPG uses Unix domain sockets to connect its components (on Windows
  an emulation of these sockets is used).  Depending on the type of
  the file system, it is sometimes not possible to use the GnuPG home
  directory (i.e. ~/.gnupg) as the location for the sockets.  To solve
  this problem GnuPG prefers the use of a per-user directory below the
  the /run (or /var/run) hierarchy for the the sockets.  It is thus
  suggested to create per-user directories on system or session
  startup.  For example the following snippet can be used in
  /etc/rc.local to create these directories:

      [ ! -d /run/user ] && mkdir /run/user
      awk -F: </etc/passwd '$3 >= 1000 && $3 < 65000 {print $3}' \
        | ( while read uid rest; do
              if [ ! -d "/run/user/$uid" ]; then
                mkdir /run/user/$uid
                chown $uid /run/user/$uid
                chmod 700 /run/user/$uid
              fi
            done )


* DOCUMENTATION

  The complete documentation is in the texinfo manual named
  `gnupg.info'.  Run "info gnupg" to read it.  If you want a a
  printable copy of the manual, change to the "doc" directory and
  enter "make pdf" For a HTML version enter "make html" and point your
  browser to gnupg.html/index.html.  Standard man pages for all
  components are provided as well.  An online version of the manual is
  available at [[https://gnupg.org/documentation/manuals/gnupg/]] .  A
  version of the manual pertaining to the current development snapshot
  is at [[https://gnupg.org/documentation/manuals/gnupg-devel/]] .


* GnuPG 1.4 and GnuPG 2.0

  GnuPG 2.0 is a newer version of GnuPG with additional support for
  S/MIME.  It has a different design philosophy that splits
  functionality up into several modules.  Both versions may be
  installed simultaneously without any conflict (gpg is called gpg2 in
  GnuPG 2).  In fact, the gpg version from GnuPG 1.4 is able to make
  use of the gpg-agent as included in GnuPG 2 and allows for seamless
  passphrase caching.  The advantage of GnuPG 1.4 is its smaller size
  and no dependency on other modules at run and build time.


* HOW TO GET MORE INFORMATION

  A description of new features and changes in version 2.1 can be
  found in the file "doc/whats-new-in-2.1.txt" and online at
  "https://gnupg.org/faq/whats-new-in-2.1.html" .

  The primary WWW page is "https://www.gnupg.org"
             or using Tor "http://ic6au7wa3f6naxjq.onion"
  The primary FTP site is "ftp://ftp.gnupg.org/gcrypt/"

  See [[https://gnupg.org/download/mirrors.html]] for a list of
  mirrors and use them if possible.  You may also find GnuPG mirrored
  on some of the regular GNU mirrors.

  We have some mailing lists dedicated to GnuPG:

     gnupg-announce@gnupg.org   For important announcements like new
                                versions and such stuff.  This is a
                                moderated list and has very low traffic.
                                Do not post to this list.

     gnupg-users@gnupg.org      For general user discussion and
                                help (English).

     gnupg-de@gnupg.org         German speaking counterpart of
                                gnupg-users.

     gnupg-ru@gnupg.org         Russian speaking counterpart of
                                gnupg-users.

     gnupg-devel@gnupg.org      GnuPG developers main forum.

  You subscribe to one of the list by sending mail with a subject of
  "subscribe" to x-request@gnupg.org, where x is the name of the
  mailing list (gnupg-announce, gnupg-users, etc.). See
  https://www.gnupg.org/documentation/mailing-lists.html for archives
  of the mailing lists.

  Please direct bug reports to http://bugs.gnupg.org or post them
  direct to the mailing list <gnupg-devel@gnupg.org>.

  Please direct questions about GnuPG to the users mailing list or one
  of the PGP newsgroups; please do not direct questions to one of the
  authors directly as we are busy working on improvements and bug
  fixes.  The English and German mailing lists are watched by the
  authors and we try to answer questions when time allows us.

  Commercial grade support for GnuPG is available; for a listing of
  offers see https://www.gnupg.org/service.html .  Maintaining and
  improving GnuPG requires a lot of time.  Since 2001, g10 Code GmbH,
  a German company owned and headed by GnuPG's principal author Werner
  Koch, is bearing the majority of these costs.  To keep GnuPG in a
  healthy state, they need your support.

  Please consider to donate at https://gnupg.org/donate/ .




4. Legal notices pertaining to the individual packets
=====================================================

GnuPG for Windows consist of several independent developed packages,
available under different license conditions.  Most of these packages
are however available under the GNU General Public License (GNU GPL).
Common to all is that they are free to use without restrictions, may
be modified and that modifications may be distributed.  If the source
file (i.e. gnupg-w32-VERSION_DATE.tar.xz) is distributed along with
the installer and the use of the GNU GPL has been pointed out,
distribution is in all cases possible.

What follows is a list of copyright statements.

Here is a list with collected copyright notices. For details see the
description of each individual package.  [Compiled by wk 2016-06-17]

GnuPG is

  Copyright (C) 1997-2016 Werner Koch
  Copyright (C) 1994-2016 Free Software Foundation, Inc.
  Copyright (C) 2003-2016 g10 Code GmbH
  Copyright (C) 2002 Klarälvdalens Datakonsult AB
  Copyright (C) 1995-1997, 2000-2007 Ulrich Drepper <drepper@gnu.ai.mit.edu>
  Copyright (C) 1994 X Consortium
  Copyright (C) 1998 by The Internet Society.
  Copyright (C) 1998-2004 The OpenLDAP Foundation
  Copyright (C) 1998-2004 Kurt D. Zeilenga.
  Copyright (C) 1998-2004 Net Boolean Incorporated.
  Copyright (C) 2001-2004 IBM Corporation.
  Copyright (C) 1999-2003 Howard Y.H. Chu.
  Copyright (C) 1999-2003 Symas Corporation.
  Copyright (C) 1998-2003 Hallvard B. Furuseth.
  Copyright (C) 1992-1996 Regents of the University of Michigan.
  Copyright (C) 2000 Dimitrios Souflis
  Copyright (C) 2008,2009,2010,2012-2016 William Ahern

  GnuPG is free software; you can redistribute it and/or modify it
  under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 3 of the License, or
  (at your option) any later version.

  GnuPG is distributed in the hope that it will be useful, but WITHOUT
  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
  License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
  02110-1301, USA

GPGME is

  Copyright (C) 2000 Werner Koch (dd9jn)
  Copyright (C) 2001, 2002, 2003, 2004, 2005, 2006 g10 Code GmbH

  GPGME is free software; you can redistribute it and/or modify it
  under the terms of the GNU Lesser General Public License as
  published by the Free Software Foundation; either version 2.1 of
  the License, or (at your option) any later version.

  GPGME is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public License
  along with this program; if not, see <http://www.gnu.org/licenses/>.

LIBGPG-ERROR is

  Copyright (C) 2003, 2004 g10 Code GmbH

  libgpg-error is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public License
  as published by the Free Software Foundation; either version 2.1 of
  the License, or (at your option) any later version.

  libgpg-error is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public License
  along with this program; if not, see <http://www.gnu.org/licenses/>.


NSIS is

  Copyright (C) 1999-2005 Nullsoft, Inc.

  This license applies to everything in the NSIS package, except where
  otherwise noted.

  This software is provided 'as-is', without any express or implied
  warranty. In no event will the authors be held liable for any
  damages arising from the use of this software.

  Permission is granted to anyone to use this software for any
  purpose, including commercial applications, and to alter it and
  redistribute it freely, subject to the following restrictions:

  1. The origin of this software must not be misrepresented; you must
     not claim that you wrote the original software. If you use this
     software in a product, an acknowledgment in the product
     documentation would be appreciated but is not required.

  2. Altered source versions must be plainly marked as such, and must
     not be misrepresented as being the original software.

  3. This notice may not be removed or altered from any source
     distribution.

  The user interface used with the installer is

  Copyright (C) 2002-2005 Joost Verburg

  [It is distributed along with NSIS and the same conditions as stated
   above apply]


ADNS is

  Copyright (C) 1997-2000,2003,2006 Ian Jackson
  Copyright (C) 1999-2000,2003,2006 Tony Finch
  Copyright (C) 1991 Massachusetts Institute of Technology


TinySCHEME is part of the GnuPG package and is

  Copyright (c) 2000, Dimitrios Souflis
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are
  met:

  Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.

  Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

  Neither the name of Dimitrios Souflis nor the names of the
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


libdns is part of the GnuPG package and is

  Copyright (c) 2008, 2009, 2010, 2012-2016  William Ahern

  Permission is hereby granted, free of charge, to any person obtaining a
  copy of this software and associated documentation files (the
  "Software"), to deal in the Software without restriction, including
  without limitation the rights to use, copy, modify, merge, publish,
  distribute, sublicense, and/or sell copies of the Software, and to permit
  persons to whom the Software is furnished to do so, subject to the
  following conditions:

  The above copyright notice and this permission notice shall be included
  in all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
  OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
  NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
  DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
  OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
  USE OR OTHER DEALINGS IN THE SOFTWARE.


SQLite has

  been put into the public-domain by its author D. Richard Hipp:
  The author disclaims copyright to this source code.  In place of
  a legal notice, here is a blessing:

      May you do good and not evil.
      May you find forgiveness for yourself and forgive others.
      May you share freely, never taking more than you give.


***end of file ***
